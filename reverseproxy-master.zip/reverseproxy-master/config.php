<?php

define('MASKED_DOMAIN', 'http://www.google.com');
define('PROXY_SUBFOLDER', 'reverseproxy');
define('FOLLOW_LOCATION', FALSE);